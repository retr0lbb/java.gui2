public class PessoaJuridica {
    private String cpnj;

    public void setCpnj(String cpnj) {
        this.cpnj = cpnj;
    }

    public String getCpnj() {
        return(cpnj);
    }
}
