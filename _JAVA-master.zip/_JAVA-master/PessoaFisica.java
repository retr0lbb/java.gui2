public class PessoaFisica {
    private String rg;

    public void setRg(String rg) {
        this.rg = rg;
    }

    public String getRg() {
        return(rg);
    }
}
